import React, { Component } from "react";
import "./style.css";
import searchIcon from "../../images/seach-icon.svg";

class Search extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: "",
    };
    this.handleChange = this.handleChange.bind(this);
  }

  handleChange = (event) => {
    console.log(event.target.value);
    this.setState({ data: event.target.value });
    //this.props.history.push("/:query");
  };

  render() {
    return (
      <div className="container-search">
        <form className="text">
          <input
            className="input-search"
            type="text"
            placeholder="Nunca dejes de buscar"
            onChange={this.handleChange}
          />
          <button className="button-search">
            <img
              src={searchIcon}
              className="search-icon "
              alt="search-icon"
            ></img>
          </button>
        </form>
      </div>
    );
  }
}
export default Search;
