const UpdateTitleHeader = (title) => {
  return {
    type: "UPDATE_TITLE",
    payload: title,
  };
};

export default UpdateTitleHeader;
