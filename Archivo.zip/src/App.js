import logo from "./images/mercado-libre.png";
import "./App.css";
import React, { Component } from "react";
import Search from "./component/search/search";
import { connect } from "react-redux";
import UpdateTitleHeader from "./store/fiture/responseSearch/actions";
import selectActiveTitle from "./store/fiture/responseSearch/reducer";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: "",
    };
  }

  componentDidMount() {
    console.log("entro aqui");
    this.props.UpdateTitleHeader("titulo nuevo");
  }
  render() {
    return (
      <div className="App">
        <div className="container">
          <div className="content">
            <img src={logo} className="App-logo " alt="logo" />
            <Search />
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  console.log(state);
  return {
    title: selectActiveTitle(state),
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    UpdateTitleHeader: () => dispatch(UpdateTitleHeader()),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(App);
